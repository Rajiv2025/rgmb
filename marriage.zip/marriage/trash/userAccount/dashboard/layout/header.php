<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title></title>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>">
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap-grid.min.css"); ?>">
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap-reboot.min.css"); ?>">
  <link rel="stylesheet" href="<?php echo base_url("assets/css/navstyle.css"); ?>">

  <script src="<?php echo base_url('assets/js/jquery.js'); ?>" charset="utf-8"></script>
  <script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>" charset="utf-8"></script>
  <script src="<?php echo base_url("assets/js/bootstrap.bundle.min.js"); ?>" charset="utf-8"></script>
</head>
<body>
