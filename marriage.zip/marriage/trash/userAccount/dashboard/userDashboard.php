<?php $this->load->view('userAccount/dashboard/layout/header'); ?>
<div class="d-flex">
  <div class="special demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
    <div class="demo-drawer mdl-layout__drawer mdl-color--blue-grey-900 mdl-color-text--blue-grey-50">
      <nav class="demo-navigation mdl-navigation mdl-color--blue-grey-800 mt-5">
        <div class="bg-link pr-3"><a class="nav-link p-4 bg-link white font-weight-bold" href="">Home</a></div>
        <div class="bg-link pr-3"><a class="nav-link p-4 bg-link white font-weight-bold" href="">My Profile</a></div>
        <div class="bg-link pr-3"><a class="nav-link p-4 bg-link white font-weight-bold" href="">Notification</a></div>
      </nav>
    </div>
  </div>

</div>








<?php $this->load->view('userAccount/dashboard/layout/footer'); ?>
