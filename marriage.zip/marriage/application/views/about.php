<?php $this->load->view('layout/header'); ?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">

<style>
.about{
  margin-top: 50px;
  width:550px;

}
.textset
{
  margin-left: 200px;
  margin-top: 30px;
  text-align: justify;
  font-size: 28px;
	font-family: 'Ubuntu', sans-serif;
}
.spantext{
  color: #DC143C;
}
.what{
 font-size: 22px;
 margin-left: 360px;
 margin-top: 28px;
 color:#DC143C;
 font-size: 30px;

}
.line{
  border: 1px solid 	#FFA500;
  width: 80%;
  margin-left: 170px;
}
</style>

<div class="container">
  <div class="row p-4">
    <div class="col-md-4">
      <img src="assets/images/indianwedding.jpg" class='about' />
    </div>
    <div class="col-md-8">
      <div class="">

        <h4 class='what'><b>WHAT WE ARE</b></h4><hr class='line'></hr>
        <h3 class="textset">A successful marriage requires falling in love many times with the same person. <span class='spantext'><b>‘RESHIM-GATHI MARRIAGE BUREAU’</b></span> brings you with authentic profiles. Find your dream partner by logging on to our website, and choose your partner by browsing through 1000s of real profiles. We pride ourself on forging hundreds of happy marriages. Login and meet your jeevansathi.</h3>
      </div>
      <div class="">
        <p></p>
      </div>
    </div>
  </div>
</div>


<?php $this->load->view('layout/footer'); ?>
