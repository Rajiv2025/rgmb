$(document).ready(function(){


  // $('select#female-select').on("change", function(){
  //   var obj = $("select#female-select option:selected");
  //   alert(obj.attr('value'));
  // });

  // $.ajax("http://localhost:8080/phpmyadmin/sql.php?server=1&db=rgmb&table=user_details&pos=0", {
  //   dataType: 'json',
  //   cache: false,
  //   contentType: 'application/json',
  // }).done(function(response){
  //   console.log(response);
  // })
});
